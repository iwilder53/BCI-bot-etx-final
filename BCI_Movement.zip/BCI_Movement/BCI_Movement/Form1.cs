﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace BCI_Movement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F)
            {
                label1.Text = "Forward";
                serialPort1.Write("1");
            }
            else if (e.KeyCode == Keys.B)
            {
                label1.Text = "Backward";
                serialPort1.Write("4");
            }
            else if (e.KeyCode == Keys.R)
            {
                label1.Text = "Right";
                serialPort1.Write("3");
            }
            else if (e.KeyCode == Keys.L)
            {
                label1.Text = "Left";
                serialPort1.Write("2");
            }
            else
            {
                label1.Text = "invalid input";
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            serialPort1.PortName = "COM10";
            serialPort1.Open();
            serialPort1.Write("<");
            serialPort1.Write("2");
            serialPort1.Write("9");
            serialPort1.Write(">");
        }
    }
}
